# Images

When adding new files here, make sure to crush them first.
You can use [libdot/bin/imgcrush](/libdot/bin/imgcrush) to do so losslessly.
